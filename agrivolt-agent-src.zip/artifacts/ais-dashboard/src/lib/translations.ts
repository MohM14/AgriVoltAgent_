export type Language = "en" | "ar";

export const translations = {
  en: {
    // Nav
    nav_dashboard: "Dashboard",
    nav_agents: "Agents",
    nav_negotiation: "Negotiation",
    nav_disease: "Disease Risk",
    nav_market: "Market",
    nav_sensors: "Sensors",
    nav_history: "History",

    // System
    system_status: "System Status",
    system_online: "online",
    system_offline: "offline",

    // Language toggle
    lang_toggle: "عربي",
    lang_toggle_ar: "English",

    // Dashboard
    energy_output: "Energy Output",
    crop_yield: "Crop Yield",
    water_flow: "Water Flow",
    disease_risk: "Disease Risk",
    revenue_today: "Revenue Today",
    land_efficiency: "Land Efficiency",
    farm_control_state: "Farm Control State",
    panel_tilt: "Panel Tilt",
    water_savings: "Water Savings",
    irrigation: "Irrigation",
    active_alerts: "Active Alerts",
    decision_cycle: "Decision Cycle",
    next_cycle_in: "Next Cycle In",
    active: "Active",
    standby: "Standby",
    latest_resolution: "Latest Resolution",
    negotiation_in_progress: "Negotiation in progress...",
    agents_computing: "Agents computing Pareto frontier via NSGA-III",
    session: "Session",
    live_agent_status: "Live Agent Status",
    winning_agents: "Winning Agents",
    tilt: "Tilt",
    irrig: "Irrig.",

    // Agents
    current_action: "Current Action",
    utility_score: "Utility Score",
    metrics: "Metrics",

    // Agent statuses
    status_active: "active",
    status_idle: "idle",
    status_negotiating: "negotiating",
    status_error: "error",

    // Negotiation
    current_session: "Current Session",
    agent_bids: "Agent Bids",
    nash_bargaining: "Nash bargaining protocol — round in progress",
    session_scores: "Session Scores",
    pareto_score: "Pareto Score",
    social_welfare: "Social Welfare",
    resolution_protocol: "Resolution Protocol",
    resolution_step_1: "Each agent submits utility function + constraints",
    resolution_step_2: "Nash Bargaining computes disagreement point",
    resolution_step_3: "Pareto frontier via NSGA-III enumeration",
    resolution_step_4: "Weighted social welfare selects balanced action",
    resolution_step_5: "Losing agents receive compensation credits",
    resolution_step_6: "Decision deployed — PPO updates agent weights",
    recent_sessions: "Recent Sessions",
    priority: "Priority",
    utility: "Utility",
    status_in_progress: "In Progress",
    status_completed: "Completed",
    status_failed: "Failed",
    winners: "Winners",

    // Disease
    overall_risk: "Overall Risk",
    risk_level_low: "Low",
    risk_level_moderate: "Moderate",
    risk_level_high: "High",
    risk_level_critical: "Critical",
    primary_threat: "Primary Threat",
    outbreak_48h: "48h Outbreak Probability",
    model: "Model",
    recommendations: "Recommendations",
    zone_risk_breakdown: "Zone Risk Breakdown",
    pathogen_detected: "Pathogen Detected",
    clear: "Clear",
    humidity: "Humidity",
    leaf_wet: "Leaf Wet.",
    shade: "Shade",
    score_out_of: "Score out of 100",

    // Market
    energy_spot_price: "Energy Spot Price",
    crop_index: "Crop Index",
    optimal_mode: "Optimal Mode",
    rising: "Rising",
    falling: "Falling",
    stable: "Stable",
    mode_maximize_energy: "Maximize Energy",
    mode_maximize_crop: "Maximize Crop",
    mode_balanced: "Balanced",
    price_forecast_24h: "24-Hour Price Forecast",
    energy_price: "Energy Price",

    // Sensors
    critical_sensors: "Critical Sensors",
    warning_sensors: "Warning Sensors",
    normal_sensors: "Normal Sensors",
    status_normal: "normal",
    status_warning: "warning",
    status_critical: "critical",

    // History
    farm_performance_history: "Farm Performance History",
    all_metrics: "All Metrics",
    last: "Last",
    crop_health: "Crop Health",
    water_usage: "Water Usage",
    revenue: "Revenue",
    max: "Max",
    min: "Min",

    // Common
    loading: "Loading...",
    not_found_title: "Agent not found",
    not_found_desc: "This route does not exist in the negotiation protocol.",
    return_dashboard: "Return to Dashboard",
    no_recent_resolution: "No recent resolution.",
  },

  ar: {
    // Nav
    nav_dashboard: "لوحة التحكم",
    nav_agents: "الوكلاء",
    nav_negotiation: "التفاوض",
    nav_disease: "مخاطر الأمراض",
    nav_market: "السوق",
    nav_sensors: "أجهزة الاستشعار",
    nav_history: "السجل",

    // System
    system_status: "حالة النظام",
    system_online: "متصل",
    system_offline: "غير متصل",

    // Language toggle
    lang_toggle: "English",
    lang_toggle_ar: "عربي",

    // Dashboard
    energy_output: "إنتاج الطاقة",
    crop_yield: "إنتاجية المحاصيل",
    water_flow: "تدفق المياه",
    disease_risk: "مخاطر الأمراض",
    revenue_today: "إيرادات اليوم",
    land_efficiency: "كفاءة الأرض",
    farm_control_state: "حالة التحكم في المزرعة",
    panel_tilt: "زاوية الميل",
    water_savings: "توفير المياه",
    irrigation: "الري",
    active_alerts: "التنبيهات النشطة",
    decision_cycle: "دورة القرار",
    next_cycle_in: "الدورة التالية خلال",
    active: "نشط",
    standby: "في انتظار",
    latest_resolution: "أحدث قرار",
    negotiation_in_progress: "جارٍ التفاوض...",
    agents_computing: "الوكلاء يحسبون حدود باريتو عبر NSGA-III",
    session: "جلسة",
    live_agent_status: "حالة الوكلاء المباشرة",
    winning_agents: "الوكلاء الفائزون",
    tilt: "الميل",
    irrig: "الري",

    // Agents
    current_action: "الإجراء الحالي",
    utility_score: "درجة المنفعة",
    metrics: "المقاييس",

    // Agent statuses
    status_active: "نشط",
    status_idle: "خامل",
    status_negotiating: "يتفاوض",
    status_error: "خطأ",

    // Negotiation
    current_session: "الجلسة الحالية",
    agent_bids: "عروض الوكلاء",
    nash_bargaining: "بروتوكول مساومة ناش — جولة جارية",
    session_scores: "نتائج الجلسة",
    pareto_score: "نقاط باريتو",
    social_welfare: "الرفاهية الاجتماعية",
    resolution_protocol: "بروتوكول الحل",
    resolution_step_1: "كل وكيل يقدم دالة المنفعة + القيود",
    resolution_step_2: "مساومة ناش تحسب نقطة الخلاف",
    resolution_step_3: "حدود باريتو تُعدّد عبر NSGA-III",
    resolution_step_4: "الرفاهية الاجتماعية الموزونة تختار الإجراء المتوازن",
    resolution_step_5: "الوكلاء الخاسرون يحصلون على أرصدة تعويضية",
    resolution_step_6: "القرار يُنفَّذ — PPO يحدّث أوزان الوكلاء",
    recent_sessions: "الجلسات الأخيرة",
    priority: "الأولوية",
    utility: "المنفعة",
    status_in_progress: "جارٍ",
    status_completed: "مكتمل",
    status_failed: "فشل",
    winners: "الفائزون",

    // Disease
    overall_risk: "المخاطر الإجمالية",
    risk_level_low: "منخفض",
    risk_level_moderate: "متوسط",
    risk_level_high: "مرتفع",
    risk_level_critical: "حرج",
    primary_threat: "التهديد الرئيسي",
    outbreak_48h: "احتمال تفشٍّ خلال 48 ساعة",
    model: "النموذج",
    recommendations: "التوصيات",
    zone_risk_breakdown: "توزيع مخاطر المناطق",
    pathogen_detected: "تم اكتشاف مسبب مرض",
    clear: "سليم",
    humidity: "الرطوبة",
    leaf_wet: "رطوبة الأوراق",
    shade: "الظل",
    score_out_of: "الدرجة من 100",

    // Market
    energy_spot_price: "سعر الطاقة الفوري",
    crop_index: "مؤشر المحاصيل",
    optimal_mode: "الوضع الأمثل",
    rising: "ارتفاع",
    falling: "انخفاض",
    stable: "مستقر",
    mode_maximize_energy: "تعظيم الطاقة",
    mode_maximize_crop: "تعظيم المحصول",
    mode_balanced: "متوازن",
    price_forecast_24h: "توقعات الأسعار لـ 24 ساعة",
    energy_price: "سعر الطاقة",

    // Sensors
    critical_sensors: "أجهزة استشعار حرجة",
    warning_sensors: "أجهزة استشعار تحذيرية",
    normal_sensors: "أجهزة استشعار طبيعية",
    status_normal: "طبيعي",
    status_warning: "تحذير",
    status_critical: "حرج",

    // History
    farm_performance_history: "سجل أداء المزرعة",
    all_metrics: "جميع المقاييس",
    last: "آخر",
    crop_health: "صحة المحاصيل",
    water_usage: "استهلاك المياه",
    revenue: "الإيرادات",
    max: "أعلى",
    min: "أدنى",

    // Common
    loading: "جارٍ التحميل...",
    not_found_title: "الوكيل غير موجود",
    not_found_desc: "هذا المسار غير موجود في بروتوكول التفاوض.",
    return_dashboard: "العودة إلى لوحة التحكم",
    no_recent_resolution: "لا يوجد قرار حديث.",
  },
} as const;

export type TranslationKey = keyof typeof translations.en;
