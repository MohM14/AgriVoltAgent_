import { Switch, Route } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { LanguageProvider } from "@/lib/i18n";
import { Layout } from "@/components/layout";
import Dashboard from "@/pages/dashboard";
import AgentsPage from "@/pages/agents";
import NegotiationPage from "@/pages/negotiation";
import DiseasePage from "@/pages/disease";
import MarketPage from "@/pages/market";
import SensorsPage from "@/pages/sensors";
import HistoryPage from "@/pages/history";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 10000,
      retry: 1,
    },
  },
});

function AppRouter() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/agents" component={AgentsPage} />
        <Route path="/negotiation" component={NegotiationPage} />
        <Route path="/disease" component={DiseasePage} />
        <Route path="/market" component={MarketPage} />
        <Route path="/sensors" component={SensorsPage} />
        <Route path="/history" component={HistoryPage} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <LanguageProvider>
        <AppRouter />
      </LanguageProvider>
    </QueryClientProvider>
  );
}
