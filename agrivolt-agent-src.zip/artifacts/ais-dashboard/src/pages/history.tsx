import { useGetFarmHistory } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Activity } from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";
import { format } from "date-fns";
import { useState } from "react";
import { cn } from "@/lib/utils";
import { useLanguage } from "@/lib/i18n";

const PERIODS = [
  { label: "6h", hours: 6 },
  { label: "12h", hours: 12 },
  { label: "24h", hours: 24 },
  { label: "48h", hours: 48 },
];

export default function HistoryPage() {
  const { t } = useLanguage();
  const [period, setPeriod] = useState(24);

  const LINES = [
    { key: "energyOutput", color: "#f59e0b", unit: "kW" },
    { key: "cropHealth", color: "#10b981", unit: "%" },
    { key: "waterUsage", color: "#38bdf8", unit: "L/h" },
    { key: "diseaseRisk", color: "#f87171", unit: "/100" },
    { key: "revenue", color: "#a78bfa", unit: "$/h" },
  ];

  const lineNames: Record<string, string> = {
    energyOutput: t("energy_output"),
    cropHealth: t("crop_health"),
    waterUsage: t("water_usage"),
    diseaseRisk: t("disease_risk"),
    revenue: t("revenue"),
  };

  const { data: history, isLoading } = useGetFarmHistory(
    { hours: period },
    { query: { refetchInterval: 60000 } }
  );

  const chartData = history?.map((p) => ({
    time: format(new Date(p.timestamp), "HH:mm"),
    energyOutput: p.energyOutput,
    cropHealth: p.cropHealth,
    waterUsage: p.waterUsage,
    diseaseRisk: p.diseaseRisk,
    revenue: p.revenue,
  })) ?? [];

  return (
    <div className="space-y-5 lg:space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
          {t("farm_performance_history")}
        </h2>
        <div className="flex gap-1 p-1 bg-muted rounded-lg">
          {PERIODS.map(({ label, hours }) => (
            <button
              key={hours}
              onClick={() => setPeriod(hours)}
              className={cn(
                "px-2.5 lg:px-3 py-1 text-xs font-medium rounded-md transition-colors",
                period === hours
                  ? "bg-background text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {isLoading ? (
        <div className="flex justify-center p-16"><Activity className="animate-spin text-primary w-8 h-8" /></div>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">
              {t("all_metrics")} — {t("last")} {period}h
            </CardTitle>
          </CardHeader>
          <CardContent className="px-2 lg:px-6">
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData} margin={{ top: 10, right: 10, left: -15, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis
                  dataKey="time"
                  tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
                  tickLine={false}
                  interval={Math.max(1, Math.floor(chartData.length / 8))}
                />
                <YAxis
                  tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
                  tickLine={false}
                  width={35}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "8px",
                    fontSize: "11px",
                  }}
                />
                <Legend wrapperStyle={{ fontSize: "11px" }} />
                {LINES.map(({ key, color }) => (
                  <Line
                    key={key}
                    type="monotone"
                    dataKey={key}
                    name={lineNames[key]}
                    stroke={color}
                    strokeWidth={1.5}
                    dot={false}
                  />
                ))}
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3 lg:gap-4">
        {LINES.map(({ key, color, unit }) => {
          const values = history?.map((p) => (p as Record<string, number>)[key]) ?? [];
          const avg = values.length ? values.reduce((a, b) => a + b, 0) / values.length : 0;
          const max = values.length ? Math.max(...values) : 0;
          const min = values.length ? Math.min(...values) : 0;
          return (
            <Card key={key}>
              <CardContent className="p-3 lg:p-4">
                <div className="text-xs text-muted-foreground font-medium mb-2 truncate">{lineNames[key]}</div>
                <div className="font-mono font-bold text-lg" style={{ color }}>
                  {avg.toFixed(1)}<span className="text-xs text-muted-foreground ms-1">{unit}</span>
                </div>
                <div className="text-[10px] text-muted-foreground mt-2 font-mono space-y-0.5">
                  <div>{t("max")}: {max.toFixed(1)}</div>
                  <div>{t("min")}: {min.toFixed(1)}</div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
