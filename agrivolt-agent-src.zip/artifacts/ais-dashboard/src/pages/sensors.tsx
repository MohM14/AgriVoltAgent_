import { useGetSensorReadings } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Activity, AlertTriangle, CheckCircle, XCircle } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { useLanguage } from "@/lib/i18n";

export default function SensorsPage() {
  const { t } = useLanguage();
  const { data: sensors, isLoading } = useGetSensorReadings({ query: { refetchInterval: 10000 } });

  if (isLoading) {
    return <div className="flex justify-center p-12"><Activity className="animate-spin text-primary w-8 h-8" /></div>;
  }

  const criticalCount = sensors?.filter((s) => s.status === "critical").length ?? 0;
  const warningCount = sensors?.filter((s) => s.status === "warning").length ?? 0;
  const normalCount = sensors?.filter((s) => s.status === "normal").length ?? 0;

  const byZone = sensors?.reduce((acc, sensor) => {
    if (!acc[sensor.zone]) acc[sensor.zone] = [];
    acc[sensor.zone].push(sensor);
    return acc;
  }, {} as Record<string, typeof sensors[number][]>);

  function statusLabel(s: string) {
    if (s === "normal") return t("status_normal");
    if (s === "warning") return t("status_warning");
    if (s === "critical") return t("status_critical");
    return s;
  }

  const statusConfig = {
    normal: { icon: CheckCircle, color: "text-emerald-500", badge: "secondary" as const, border: "" },
    warning: { icon: AlertTriangle, color: "text-amber-500", badge: "outline" as const, border: "border-amber-500/30" },
    critical: { icon: XCircle, color: "text-destructive", badge: "destructive" as const, border: "border-destructive/40" },
  };

  return (
    <div className="space-y-5 lg:space-y-6">
      <div className="grid grid-cols-3 gap-3 lg:gap-4">
        {[
          { label: t("critical_sensors"), count: criticalCount, color: "text-destructive", bg: "bg-destructive/10" },
          { label: t("warning_sensors"), count: warningCount, color: "text-amber-500", bg: "bg-amber-500/10" },
          { label: t("normal_sensors"), count: normalCount, color: "text-emerald-500", bg: "bg-emerald-500/10" },
        ].map(({ label, count, color, bg }) => (
          <Card key={label}>
            <CardContent className={cn("p-4 lg:p-6 flex flex-col sm:flex-row items-center gap-3", bg)}>
              <div className={cn("text-3xl lg:text-4xl font-black font-mono", color)}>{count}</div>
              <div className="text-xs lg:text-sm font-medium text-muted-foreground text-center sm:text-start">{label}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      {byZone && Object.entries(byZone).map(([zone, zoneSensors], zi) => (
        <motion.div
          key={zone}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: zi * 0.07 }}
        >
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-semibold">{zone}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 lg:gap-3">
                {zoneSensors.map((sensor) => {
                  const cfg = statusConfig[sensor.status as keyof typeof statusConfig] ?? statusConfig.normal;
                  const StatusIcon = cfg.icon;
                  return (
                    <div
                      key={sensor.id}
                      className={cn(
                        "p-3 rounded-lg border bg-card",
                        sensor.status !== "normal" ? cfg.border : "border-border"
                      )}
                    >
                      <div className="flex justify-between items-start mb-2">
                        <StatusIcon className={cn("w-3.5 h-3.5", cfg.color)} />
                        <Badge variant={cfg.badge} className="text-[9px] px-1.5 py-0">
                          {statusLabel(sensor.status)}
                        </Badge>
                      </div>
                      <div className="text-xs text-muted-foreground capitalize mb-1">{sensor.type}</div>
                      <div className="font-mono font-bold text-lg">{sensor.value}</div>
                      <div className="text-[10px] text-muted-foreground">{sensor.unit}</div>
                      <div className="text-[10px] text-muted-foreground/60 mt-1 font-mono">
                        {format(new Date(sensor.timestamp), "HH:mm:ss")}
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
}
