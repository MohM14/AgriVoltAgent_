import { useGetFarmMetrics, useGetAgents, useGetCurrentNegotiation } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Activity, Droplets, Leaf, Zap, AlertTriangle, Coins, BarChart3 } from "lucide-react";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { useLanguage } from "@/lib/i18n";

export default function Dashboard() {
  const { t } = useLanguage();
  const { data: metrics, isLoading: isMetricsLoading } = useGetFarmMetrics({ query: { refetchInterval: 15000 } });
  const { data: agents, isLoading: isAgentsLoading } = useGetAgents({ query: { refetchInterval: 15000 } });
  const { data: negotiation } = useGetCurrentNegotiation({ query: { refetchInterval: 15000 } });

  if (isMetricsLoading || isAgentsLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Activity className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!metrics) return null;

  const metricCards = [
    { title: t("energy_output"), value: `${metrics.energyOutput.toFixed(1)} kW`, icon: Zap, color: "text-amber-500" },
    { title: t("crop_yield"), value: `${metrics.cropYield.toFixed(0)} kg`, icon: Leaf, color: "text-emerald-500" },
    { title: t("water_flow"), value: `${metrics.waterUsage.toFixed(0)} L/h`, icon: Droplets, color: "text-sky-500" },
    { title: t("disease_risk"), value: `${metrics.diseaseRiskScore.toFixed(0)}/100`, icon: AlertTriangle, color: metrics.diseaseRiskScore > 50 ? "text-destructive" : "text-amber-500" },
    { title: t("revenue_today"), value: `$${metrics.revenueToday.toFixed(0)}`, icon: Coins, color: "text-emerald-400" },
    { title: t("land_efficiency"), value: `${(metrics.landUseEfficiency * 100).toFixed(0)}%`, icon: BarChart3, color: "text-purple-400" },
  ];

  const stateItems = [
    { label: t("panel_tilt"), value: `${metrics.panelTiltDegrees}°`, mono: true },
    { label: t("water_savings"), value: `${metrics.waterSavings.toFixed(0)} L`, mono: true },
    { label: t("irrigation"), value: metrics.irrigationActive ? t("active") : t("standby"), active: metrics.irrigationActive },
    { label: t("active_alerts"), value: String(metrics.alertCount), alert: metrics.alertCount > 0 },
    { label: t("decision_cycle"), value: `#${metrics.cycleCount}`, mono: true },
    { label: t("next_cycle_in"), value: `${metrics.nextCycleIn}s`, pulse: true },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {metricCards.map((card, i) => (
          <motion.div
            key={card.title}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
          >
            <Card className="h-full">
              <CardContent className="p-4 flex flex-col gap-2">
                <div className={cn("p-2 rounded-md bg-muted w-fit", card.color)}>
                  <card.icon className="w-4 h-4" />
                </div>
                <div className="text-xs text-muted-foreground font-medium">{card.title}</div>
                <div className="text-xl font-bold font-mono">{card.value}</div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="col-span-1 lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">{t("farm_control_state")}</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-2 gap-3">
            {stateItems.map(({ label, value, mono, active, alert, pulse }) => (
              <div
                key={label}
                className={cn(
                  "flex justify-between items-center p-3 rounded-lg bg-muted/40",
                  alert && "bg-destructive/10 border border-destructive/20",
                  active && "bg-emerald-500/10 border border-emerald-500/20"
                )}
              >
                <span className="text-sm font-medium text-muted-foreground">{label}</span>
                <span className={cn(
                  "text-sm font-bold",
                  mono && "font-mono",
                  pulse && "animate-pulse text-primary",
                  alert && "text-destructive",
                  active && "text-emerald-500"
                )}>
                  {value}
                </span>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">{t("latest_resolution")}</CardTitle>
          </CardHeader>
          <CardContent>
            {negotiation?.resolution ? (
              <div className="space-y-3">
                <div className="text-sm font-semibold leading-snug">{negotiation.resolution.action}</div>
                <p className="text-xs text-muted-foreground leading-relaxed">{negotiation.resolution.explanation}</p>
                <div className="pt-3 border-t border-border space-y-2">
                  <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{t("winning_agents")}</div>
                  <div className="flex flex-wrap gap-1.5">
                    {negotiation.resolution.winningAgents.map((a) => (
                      <Badge key={a} variant="outline" className="text-xs capitalize">{a}</Badge>
                    ))}
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2 pt-1 text-xs font-mono">
                  <div className="bg-muted/40 rounded p-2">
                    <div className="text-muted-foreground">{t("tilt")}</div>
                    <div className="font-bold">{negotiation.resolution.panelTiltDegrees}°</div>
                  </div>
                  <div className="bg-muted/40 rounded p-2">
                    <div className="text-muted-foreground">{t("irrig")}</div>
                    <div className="font-bold">{(negotiation.resolution.irrigationRate * 100).toFixed(0)}%</div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-2 animate-pulse">
                <div className="text-sm font-semibold text-primary">{t("negotiation_in_progress")}</div>
                <p className="text-xs text-muted-foreground">{t("agents_computing")}</p>
                <div className="text-xs font-mono text-muted-foreground">{t("session")} #{negotiation?.id}</div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div>
        <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground mb-4">
          {t("live_agent_status")}
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-8 gap-3">
          {agents?.map((agent, i) => (
            <motion.div
              key={agent.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.04 }}
            >
              <Card className={cn(
                "h-full border-t-2",
                agent.status === "active" ? "border-t-emerald-500" :
                agent.status === "negotiating" ? "border-t-primary" :
                agent.status === "error" ? "border-t-destructive" :
                "border-t-muted-foreground/30"
              )}>
                <CardContent className="p-3 flex flex-col items-center text-center gap-1.5">
                  <div className={cn(
                    "w-2 h-2 rounded-full mt-1",
                    agent.status === "active" ? "bg-emerald-500 animate-pulse" :
                    agent.status === "negotiating" ? "bg-primary animate-pulse" :
                    agent.status === "error" ? "bg-destructive" :
                    "bg-muted-foreground/40"
                  )} />
                  <div className="font-semibold text-xs leading-tight">{agent.name}</div>
                  <div className="text-[10px] text-muted-foreground font-mono">
                    {agent.utilityScore.toFixed(2)}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
