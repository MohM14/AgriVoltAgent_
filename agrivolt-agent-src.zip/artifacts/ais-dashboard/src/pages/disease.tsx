import { useGetDiseaseRisk } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Activity, AlertTriangle, CheckCircle, ShieldAlert } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { useLanguage } from "@/lib/i18n";

const riskConfig = {
  low: { color: "text-emerald-500", bg: "bg-emerald-500/10", border: "border-emerald-500/30", badge: "secondary" as const },
  moderate: { color: "text-amber-500", bg: "bg-amber-500/10", border: "border-amber-500/30", badge: "outline" as const },
  high: { color: "text-orange-500", bg: "bg-orange-500/10", border: "border-orange-500/30", badge: "default" as const },
  critical: { color: "text-destructive", bg: "bg-destructive/10", border: "border-destructive/30", badge: "destructive" as const },
};

export default function DiseasePage() {
  const { t } = useLanguage();
  const { data: risk, isLoading } = useGetDiseaseRisk({ query: { refetchInterval: 30000 } });

  if (isLoading) {
    return <div className="flex justify-center p-12"><Activity className="animate-spin text-primary w-8 h-8" /></div>;
  }
  if (!risk) return null;

  const cfg = riskConfig[risk.riskLevel];

  function riskLevelLabel(level: string) {
    if (level === "low") return t("risk_level_low");
    if (level === "moderate") return t("risk_level_moderate");
    if (level === "high") return t("risk_level_high");
    if (level === "critical") return t("risk_level_critical");
    return level;
  }

  return (
    <div className="space-y-5 lg:space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-6">
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
          <Card className={cn("border", cfg.border)}>
            <CardContent className="p-5 lg:p-6">
              <div className="flex items-center gap-3 mb-4">
                <ShieldAlert className={cn("w-6 h-6 flex-shrink-0", cfg.color)} />
                <div>
                  <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{t("overall_risk")}</div>
                  <Badge variant={cfg.badge} className="mt-1">
                    {riskLevelLabel(risk.riskLevel)}
                  </Badge>
                </div>
              </div>
              <div className={cn("text-5xl font-black font-mono mb-3", cfg.color)}>
                {risk.overallRisk.toFixed(0)}
              </div>
              <div className="h-3 bg-muted rounded-full overflow-hidden">
                <div
                  className={cn("h-full rounded-full transition-all duration-500", cfg.color.replace("text-", "bg-"))}
                  style={{ width: `${risk.overallRisk}%` }}
                />
              </div>
              <div className="text-xs text-muted-foreground mt-2">{t("score_out_of")}</div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}>
          <Card>
            <CardContent className="p-5 lg:p-6 space-y-4">
              <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{t("primary_threat")}</div>
              <div className="font-semibold text-sm font-mono break-words">{risk.primaryThreat}</div>
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-muted-foreground">{t("outbreak_48h")}</span>
                  <span className={cn("font-mono font-bold", risk.probability48h > 0.5 ? "text-destructive" : "text-amber-500")}>
                    {(risk.probability48h * 100).toFixed(0)}%
                  </span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className={cn("h-full rounded-full", risk.probability48h > 0.5 ? "bg-destructive" : "bg-amber-500")}
                    style={{ width: `${risk.probability48h * 100}%` }}
                  />
                </div>
              </div>
              <div className="text-xs text-muted-foreground pt-1">
                {t("model")}: <span className="font-mono">{risk.modelVersion}</span>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <Card className="sm:col-span-2 lg:col-span-1">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">{t("recommendations")}</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {risk.recommendations.map((rec, i) => (
                  <li key={i} className="flex gap-2 text-xs">
                    <AlertTriangle className="w-3 h-3 flex-shrink-0 text-amber-500 mt-0.5" />
                    <span>{rec}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <div>
        <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground mb-4">
          {t("zone_risk_breakdown")}
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3 lg:gap-4">
          {risk.zones.map((zone, i) => {
            const zoneRisk = zone.riskScore >= 60 ? "high" : zone.riskScore >= 40 ? "moderate" : "low";
            const zoneCfg = riskConfig[zoneRisk];
            return (
              <motion.div
                key={zone.zoneId}
                initial={{ opacity: 0, scale: 0.97 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.06 }}
              >
                <Card className={cn("border", zone.pathogenDetected ? "border-destructive/40" : zoneCfg.border)}>
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <div className="font-semibold text-sm">{zone.zoneName}</div>
                        {zone.pathogenDetected ? (
                          <Badge variant="destructive" className="text-[10px] mt-1">{t("pathogen_detected")}</Badge>
                        ) : (
                          <Badge variant="secondary" className="text-[10px] mt-1 gap-1">
                            <CheckCircle className="w-2.5 h-2.5" />
                            {t("clear")}
                          </Badge>
                        )}
                      </div>
                      <div className={cn("text-2xl font-black font-mono", zoneCfg.color)}>
                        {zone.riskScore.toFixed(0)}
                      </div>
                    </div>
                    <div className="h-1.5 bg-muted rounded-full overflow-hidden mb-4">
                      <div
                        className={cn("h-full rounded-full", zoneCfg.color.replace("text-", "bg-"))}
                        style={{ width: `${zone.riskScore}%` }}
                      />
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-xs">
                      {[
                        { label: t("humidity"), value: `${zone.humidity.toFixed(0)}%`, warn: zone.humidity > 75 },
                        { label: t("leaf_wet"), value: `${zone.leafWetness.toFixed(0)}%`, warn: zone.leafWetness > 30 },
                        { label: t("shade"), value: `${zone.shadePercent.toFixed(0)}%`, warn: zone.shadePercent > 45 },
                      ].map(({ label, value, warn }) => (
                        <div key={label} className={cn("rounded p-2 bg-muted/40", warn && "bg-amber-500/10")}>
                          <div className="text-muted-foreground truncate">{label}</div>
                          <div className={cn("font-mono font-bold mt-0.5", warn && "text-amber-500")}>{value}</div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
