import { useGetMarketPrices, useGetMarketForecast } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Activity, TrendingUp, TrendingDown, Minus, Zap, Leaf } from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { useLanguage } from "@/lib/i18n";

const trendIcon = {
  rising: TrendingUp,
  falling: TrendingDown,
  stable: Minus,
};
const trendColor = {
  rising: "text-emerald-500",
  falling: "text-destructive",
  stable: "text-muted-foreground",
};

export default function MarketPage() {
  const { t } = useLanguage();
  const { data: prices, isLoading } = useGetMarketPrices({ query: { refetchInterval: 15000 } });
  const { data: forecast, isLoading: isForecastLoading } = useGetMarketForecast({ query: { refetchInterval: 60000 } });

  if (isLoading) {
    return <div className="flex justify-center p-12"><Activity className="animate-spin text-primary w-8 h-8" /></div>;
  }
  if (!prices) return null;

  const EnergyTrendIcon = trendIcon[prices.energyTrend];
  const CropTrendIcon = trendIcon[prices.cropTrend];

  function trendLabel(trend: string) {
    if (trend === "rising") return t("rising");
    if (trend === "falling") return t("falling");
    return t("stable");
  }

  function modeLabel(mode: string) {
    if (mode === "maximize_energy") return t("mode_maximize_energy");
    if (mode === "maximize_crop") return t("mode_maximize_crop");
    return t("mode_balanced");
  }

  const modeBg =
    prices.optimalMode === "maximize_energy"
      ? "bg-amber-500/10"
      : prices.optimalMode === "maximize_crop"
      ? "bg-emerald-500/10"
      : "bg-primary/10";
  const modeColor =
    prices.optimalMode === "maximize_energy"
      ? "text-amber-500"
      : prices.optimalMode === "maximize_crop"
      ? "text-emerald-500"
      : "text-primary";

  const chartData = forecast?.map((p) => ({
    time: format(new Date(p.timestamp), "HH:mm"),
    energy: p.energyPrice,
    crop: p.cropIndex / 100,
  })) ?? [];

  return (
    <div className="space-y-5 lg:space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-6">
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
          <Card>
            <CardContent className="p-5 lg:p-6">
              <div className="flex items-center gap-2 mb-3">
                <Zap className="w-4 h-4 text-amber-500 flex-shrink-0" />
                <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{t("energy_spot_price")}</div>
              </div>
              <div className="flex items-end gap-2 flex-wrap">
                <div className="text-3xl lg:text-4xl font-black font-mono text-amber-500">${prices.energySpotPrice.toFixed(3)}</div>
                <div className="text-sm text-muted-foreground mb-1">{prices.energyUnit}</div>
              </div>
              <div className={cn("flex items-center gap-1 mt-2 text-sm font-medium", trendColor[prices.energyTrend])}>
                <EnergyTrendIcon className="w-4 h-4" />
                <span>{trendLabel(prices.energyTrend)}</span>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}>
          <Card>
            <CardContent className="p-5 lg:p-6">
              <div className="flex items-center gap-2 mb-3">
                <Leaf className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{t("crop_index")}</div>
              </div>
              <div className="flex items-end gap-2 flex-wrap">
                <div className="text-3xl lg:text-4xl font-black font-mono text-emerald-500">{prices.cropIndex.toFixed(1)}</div>
                <div className="text-sm text-muted-foreground mb-1">{prices.cropUnit}</div>
              </div>
              <div className={cn("flex items-center gap-1 mt-2 text-sm font-medium", trendColor[prices.cropTrend])}>
                <CropTrendIcon className="w-4 h-4" />
                <span>{trendLabel(prices.cropTrend)}</span>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <Card className={cn("border sm:col-span-2 lg:col-span-1", modeBg)}>
            <CardContent className="p-5 lg:p-6">
              <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">{t("optimal_mode")}</div>
              <div className={cn("text-xl font-bold mb-2", modeColor)}>{modeLabel(prices.optimalMode)}</div>
              <p className="text-sm text-muted-foreground leading-relaxed">{prices.recommendation}</p>
              <div className="mt-4 pt-4 border-t border-border text-xs font-mono text-muted-foreground">
                {format(new Date(prices.timestamp), "MMM d, HH:mm:ss")}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">{t("price_forecast_24h")}</CardTitle>
        </CardHeader>
        <CardContent className="px-2 lg:px-6">
          {isForecastLoading ? (
            <div className="flex justify-center p-8"><Activity className="animate-spin text-primary w-6 h-6" /></div>
          ) : (
            <ResponsiveContainer width="100%" height={260}>
              <LineChart data={chartData} margin={{ top: 5, right: 10, left: -10, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis
                  dataKey="time"
                  tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
                  tickLine={false}
                  interval={Math.max(1, Math.floor(chartData.length / 8))}
                />
                <YAxis
                  yAxisId="energy"
                  tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
                  tickLine={false}
                  tickFormatter={(v) => `$${v.toFixed(2)}`}
                  width={45}
                />
                <YAxis
                  yAxisId="crop"
                  orientation="right"
                  tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
                  tickLine={false}
                  tickFormatter={(v) => `${(v * 100).toFixed(0)}`}
                  width={35}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "8px",
                    fontSize: "12px",
                  }}
                  formatter={(v: number, name: string) =>
                    name === t("energy_price")
                      ? [`$${v.toFixed(3)}/kWh`, name]
                      : [`${(v * 100).toFixed(1)}`, name]
                  }
                />
                <Legend wrapperStyle={{ fontSize: "11px" }} />
                <Line yAxisId="energy" type="monotone" dataKey="energy" name={t("energy_price")} stroke="#f59e0b" strokeWidth={2} dot={false} />
                <Line yAxisId="crop" type="monotone" dataKey="crop" name={t("crop_index")} stroke="#10b981" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
