import { useGetAgents } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { Activity } from "lucide-react";
import { useLanguage } from "@/lib/i18n";

export default function AgentsPage() {
  const { t } = useLanguage();
  const { data: agents, isLoading } = useGetAgents({ query: { refetchInterval: 15000 } });

  if (isLoading) {
    return <div className="flex justify-center p-12"><Activity className="animate-spin text-primary w-8 h-8" /></div>;
  }

  function statusLabel(s: string) {
    if (s === "active") return t("status_active");
    if (s === "idle") return t("status_idle");
    if (s === "negotiating") return t("status_negotiating");
    if (s === "error") return t("status_error");
    return s;
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-4 gap-6">
        {agents?.map((agent) => (
          <Card
            key={agent.id}
            className={cn(
              "transition-all duration-300 border-s-4",
              agent.status === "error" ? "border-s-destructive" :
              agent.status === "negotiating" ? "border-s-primary shadow-md" :
              agent.status === "active" ? "border-s-emerald-500" :
              "border-s-muted"
            )}
          >
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-lg">{agent.name}</CardTitle>
                  <CardDescription className="text-xs font-mono uppercase tracking-wider mt-1">{agent.role}</CardDescription>
                </div>
                <Badge
                  variant={
                    agent.status === "error" ? "destructive" :
                    agent.status === "negotiating" ? "default" :
                    agent.status === "active" ? "secondary" : "outline"
                  }
                >
                  {statusLabel(agent.status)}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="text-xs text-muted-foreground uppercase tracking-wider font-semibold mb-1">
                  {t("current_action")}
                </div>
                <div className="text-sm font-medium leading-snug">{agent.currentAction}</div>
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-border">
                <div className="text-xs text-muted-foreground">{t("utility_score")}</div>
                <div className="font-mono font-bold text-primary">{agent.utilityScore.toFixed(2)}</div>
              </div>

              <div className="pt-2">
                <div className="text-xs text-muted-foreground mb-2">{t("metrics")}</div>
                <div className="grid grid-cols-2 gap-2">
                  {Object.entries(agent.metrics).map(([key, value]) => (
                    <div key={key} className="bg-muted/50 rounded p-2 flex flex-col">
                      <span className="text-[10px] text-muted-foreground truncate" title={key}>{key}</span>
                      <span className="font-mono text-xs font-medium">
                        {typeof value === "number" ? value.toFixed(2) : value}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
