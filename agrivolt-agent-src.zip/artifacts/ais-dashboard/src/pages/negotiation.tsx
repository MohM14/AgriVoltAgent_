import {
  useGetCurrentNegotiation,
  useGetNegotiationSessions,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Activity, CheckCircle, XCircle } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { useLanguage } from "@/lib/i18n";

export default function NegotiationPage() {
  const { t } = useLanguage();
  const { data: current } = useGetCurrentNegotiation({ query: { refetchInterval: 10000 } });
  const { data: sessions, isLoading } = useGetNegotiationSessions(
    { limit: 10 },
    { query: { refetchInterval: 30000 } }
  );

  const resolutionSteps = [
    t("resolution_step_1"),
    t("resolution_step_2"),
    t("resolution_step_3"),
    t("resolution_step_4"),
    t("resolution_step_5"),
    t("resolution_step_6"),
  ];

  function sessionStatusLabel(status: string) {
    if (status === "in_progress") return t("status_in_progress");
    if (status === "completed") return t("status_completed");
    if (status === "failed") return t("status_failed");
    return status;
  }

  return (
    <div className="space-y-6">
      {current && (
        <div>
          <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground mb-4">
            {t("current_session")} — #{current.id}
          </h2>
          <div className="grid grid-cols-1 xl:grid-cols-5 gap-4 lg:gap-6">
            <Card className="xl:col-span-3">
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Activity className="w-4 h-4 text-primary animate-pulse" />
                  {t("agent_bids")}
                </CardTitle>
                <CardDescription className="text-xs">{t("nash_bargaining")}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {current.bids.map((bid, i) => (
                  <motion.div
                    key={bid.agentId}
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.07 }}
                    className="p-3 lg:p-4 rounded-lg border border-border bg-muted/20"
                  >
                    <div className="flex justify-between items-start gap-2 mb-2">
                      <div className="min-w-0">
                        <span className="font-semibold text-sm">{bid.agentName}</span>
                        <div className="text-xs font-mono text-muted-foreground mt-0.5">
                          {t("priority")}: {bid.priority.toFixed(2)} · {t("utility")}: +{bid.utilityGain.toFixed(2)}
                        </div>
                      </div>
                      <div className="w-12 lg:w-16 h-1.5 rounded-full bg-muted overflow-hidden flex-shrink-0 mt-2">
                        <div
                          className="h-full bg-primary rounded-full"
                          style={{ width: `${bid.priority * 100}%` }}
                        />
                      </div>
                    </div>
                    <p className="text-sm font-medium text-foreground mb-2 break-words">"{bid.bid}"</p>
                    <div className="flex flex-wrap gap-1">
                      {bid.constraints.map((c) => (
                        <Badge key={c} variant="outline" className="text-[10px] font-mono">{c}</Badge>
                      ))}
                    </div>
                  </motion.div>
                ))}
              </CardContent>
            </Card>

            <Card className="xl:col-span-2">
              <CardHeader>
                <CardTitle className="text-base">{t("session_scores")}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">{t("pareto_score")}</span>
                    <span className="font-mono font-bold">{current.paretoScore.toFixed(2)}</span>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-primary rounded-full transition-all" style={{ width: `${current.paretoScore * 100}%` }} />
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">{t("social_welfare")}</span>
                    <span className="font-mono font-bold">{current.socialWelfareScore.toFixed(2)}</span>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-emerald-500 rounded-full transition-all" style={{ width: `${current.socialWelfareScore * 100}%` }} />
                  </div>
                </div>

                <div className="pt-4 border-t border-border">
                  <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">
                    {t("resolution_protocol")}
                  </div>
                  <ol className="space-y-2 text-xs">
                    {resolutionSteps.map((step, i) => (
                      <li key={i} className={cn(
                        "flex gap-2 items-start",
                        current.status === "in_progress" && i <= 2 ? "text-foreground" : "text-muted-foreground"
                      )}>
                        <span className={cn(
                          "flex-shrink-0 w-4 h-4 rounded-full flex items-center justify-center text-[10px] font-bold mt-0.5",
                          current.status === "in_progress" && i <= 2
                            ? "bg-primary text-primary-foreground"
                            : "bg-muted text-muted-foreground"
                        )}>{i + 1}</span>
                        {step}
                      </li>
                    ))}
                  </ol>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}

      <div>
        <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground mb-4">
          {t("recent_sessions")}
        </h2>
        {isLoading ? (
          <div className="flex justify-center p-12"><Activity className="animate-spin text-primary w-6 h-6" /></div>
        ) : (
          <div className="space-y-3">
            {sessions?.map((session, i) => {
              const isCompleted = session.status === "completed";
              const isFailed = session.status === "failed";
              const StatusIcon = isCompleted ? CheckCircle : isFailed ? XCircle : Activity;
              const statusColor = isCompleted ? "text-emerald-500" : isFailed ? "text-destructive" : "text-primary";
              const badgeVariant = isFailed ? "destructive" as const : isCompleted ? "secondary" as const : "default" as const;

              return (
                <motion.div
                  key={session.id}
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.04 }}
                >
                  <Card>
                    <CardContent className="p-3 lg:p-4">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-center gap-3 min-w-0">
                          <StatusIcon className={cn("w-4 h-4 flex-shrink-0", statusColor)} />
                          <div className="min-w-0">
                            <div className="text-sm font-semibold">{t("session")} #{session.id}</div>
                            <div className="text-xs text-muted-foreground font-mono">
                              {format(new Date(session.startedAt), "MMM d, HH:mm:ss")}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 lg:gap-3 text-right flex-shrink-0">
                          <div className="hidden sm:block">
                            <div className="text-xs font-mono">
                              {t("pareto_score")}: <span className="text-primary font-bold">{session.paretoScore.toFixed(2)}</span>
                              <span className="hidden md:inline"> · {t("social_welfare")}: <span className="text-emerald-500 font-bold">{session.socialWelfareScore.toFixed(2)}</span></span>
                            </div>
                          </div>
                          <Badge variant={badgeVariant} className="text-xs whitespace-nowrap">{sessionStatusLabel(session.status)}</Badge>
                        </div>
                      </div>
                      {session.resolution && (
                        <div className="mt-3 pt-3 border-t border-border flex flex-wrap gap-1">
                          <span className="text-xs text-muted-foreground me-1">{t("winners")}:</span>
                          {session.resolution.winningAgents.map((a) => (
                            <Badge key={a} variant="outline" className="text-[10px] capitalize">{a}</Badge>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
