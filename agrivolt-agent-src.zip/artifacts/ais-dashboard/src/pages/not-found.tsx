import { Link } from "wouter";
import { Home } from "lucide-react";
import { motion } from "framer-motion";
import { useLanguage } from "@/lib/i18n";

export default function NotFound() {
  const { t } = useLanguage();
  return (
    <div className="flex flex-col items-center justify-center h-64 text-center">
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
        <div className="text-8xl font-black font-mono text-muted-foreground/20 mb-4">404</div>
        <div className="text-xl font-semibold mb-2">{t("not_found_title")}</div>
        <p className="text-sm text-muted-foreground mb-6">{t("not_found_desc")}</p>
        <Link href="/" className="inline-flex items-center gap-2 text-sm text-primary hover:underline font-medium">
          <Home className="w-4 h-4" />
          {t("return_dashboard")}
        </Link>
      </motion.div>
    </div>
  );
}
