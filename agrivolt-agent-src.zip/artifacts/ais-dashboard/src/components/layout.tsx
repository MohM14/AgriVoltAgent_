import { Link, useLocation } from "wouter";
import { useHealthCheck } from "@workspace/api-client-react";
import {
  Activity,
  Cpu,
  CloudRain,
  LineChart,
  AlertTriangle,
  History,
  ActivityIcon,
  Sun,
  Languages,
  Menu,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { useLanguage } from "@/lib/i18n";
import type { TranslationKey } from "@/lib/translations";
import { useState, useEffect } from "react";

const navItems: { href: string; labelKey: TranslationKey; icon: React.ElementType }[] = [
  { href: "/", labelKey: "nav_dashboard", icon: Activity },
  { href: "/agents", labelKey: "nav_agents", icon: Cpu },
  { href: "/negotiation", labelKey: "nav_negotiation", icon: ActivityIcon },
  { href: "/disease", labelKey: "nav_disease", icon: AlertTriangle },
  { href: "/market", labelKey: "nav_market", icon: LineChart },
  { href: "/sensors", labelKey: "nav_sensors", icon: CloudRain },
  { href: "/history", labelKey: "nav_history", icon: History },
];

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { data: health } = useHealthCheck({ query: { refetchInterval: 15000 } });
  const { t, lang, setLang, isRTL } = useLanguage();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Close sidebar on route change (mobile)
  useEffect(() => {
    setSidebarOpen(false);
  }, [location]);

  // Close sidebar on wide screen
  useEffect(() => {
    const mq = window.matchMedia("(min-width: 1024px)");
    const handler = (e: MediaQueryListEvent) => { if (e.matches) setSidebarOpen(false); };
    mq.addEventListener("change", handler);
    return () => mq.removeEventListener("change", handler);
  }, []);

  const currentNavLabel = navItems.find((item) => item.href === location)?.labelKey;

  const sidebarContent = (
    <>
      {/* Logo */}
      <div className="h-16 flex items-center px-6 border-b border-border flex-shrink-0">
        <div className="flex items-center gap-2 text-primary">
          <Sun className="w-6 h-6" />
          <div>
            <div className="font-bold tracking-tight leading-none text-sm">AgriVolt</div>
            <div className="font-bold tracking-tight leading-none text-primary/70 text-xs">Agent</div>
          </div>
        </div>
        {/* Mobile close button */}
        <button
          className="lg:hidden ms-auto p-1.5 rounded-md hover:bg-sidebar-accent text-sidebar-foreground/60 hover:text-sidebar-foreground"
          onClick={() => setSidebarOpen(false)}
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-4">
        <ul className="space-y-1 px-3">
          {navItems.map((item) => {
            const isActive = location === item.href;
            const Icon = item.icon;
            return (
              <li key={item.href}>
                <Link
                  href={item.href}
                  className={cn(
                    "flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors",
                    isActive
                      ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-sm"
                      : "hover:bg-sidebar-accent hover:text-sidebar-accent-foreground text-sidebar-foreground/80"
                  )}
                >
                  <Icon className="w-4 h-4 flex-shrink-0" />
                  {t(item.labelKey)}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      {/* System status + language toggle */}
      <div className="p-4 border-t border-border bg-sidebar-accent/30 text-xs space-y-3 flex-shrink-0">
        <div className="flex items-center justify-between">
          <span className="text-muted-foreground font-mono">{t("system_status")}</span>
          <div className="flex items-center gap-1.5">
            <div
              className={cn(
                "w-2 h-2 rounded-full",
                health?.status === "ok" ? "bg-primary animate-pulse" : "bg-destructive"
              )}
            />
            <span className="font-mono font-medium">
              {health?.status === "ok" ? t("system_online") : t("system_offline")}
            </span>
          </div>
        </div>

        {/* Language toggle */}
        <button
          onClick={() => setLang(lang === "en" ? "ar" : "en")}
          className="w-full flex items-center justify-between px-3 py-2 rounded-md bg-sidebar-accent hover:bg-sidebar-accent/80 transition-colors text-sidebar-foreground/80 hover:text-sidebar-foreground"
        >
          <div className="flex items-center gap-2">
            <Languages className="w-3.5 h-3.5" />
            <span className="font-medium">{lang === "en" ? "عربي" : "English"}</span>
          </div>
          <span className="font-mono text-[10px] text-muted-foreground uppercase tracking-wider">
            {lang === "en" ? "AR" : "EN"}
          </span>
        </button>
      </div>
    </>
  );

  return (
    <div
      className="flex h-screen overflow-hidden bg-background text-foreground font-sans"
      dir={isRTL ? "rtl" : "ltr"}
    >
      {/* ── Desktop sidebar (always visible ≥ lg) ── */}
      <aside
        className={cn(
          "hidden lg:flex w-64 flex-shrink-0 flex-col bg-sidebar text-sidebar-foreground",
          isRTL ? "border-l border-border" : "border-r border-border"
        )}
      >
        {sidebarContent}
      </aside>

      {/* ── Mobile sidebar drawer overlay ── */}
      {sidebarOpen && (
        <div
          className="lg:hidden fixed inset-0 z-40 bg-black/60 backdrop-blur-sm"
          onClick={() => setSidebarOpen(false)}
        />
      )}
      <aside
        className={cn(
          "lg:hidden fixed top-0 bottom-0 z-50 w-72 flex flex-col bg-sidebar text-sidebar-foreground transition-transform duration-300",
          isRTL
            ? cn("right-0 border-l border-border", sidebarOpen ? "translate-x-0" : "translate-x-full")
            : cn("left-0 border-r border-border", sidebarOpen ? "translate-x-0" : "-translate-x-full")
        )}
      >
        {sidebarContent}
      </aside>

      {/* ── Main content ── */}
      <main className="flex-1 flex flex-col overflow-hidden min-w-0">
        {/* Header */}
        <header className="h-14 lg:h-16 flex-shrink-0 border-b border-border bg-card/50 backdrop-blur flex items-center justify-between px-4 lg:px-8 z-10 relative gap-3">
          {/* Hamburger (mobile only) */}
          <button
            className="lg:hidden p-2 rounded-md hover:bg-muted text-muted-foreground hover:text-foreground transition-colors flex-shrink-0"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu className="w-5 h-5" />
          </button>

          <h1 className="text-base lg:text-xl font-semibold tracking-tight truncate flex-1">
            {currentNavLabel ? t(currentNavLabel) : t("nav_dashboard")}
          </h1>

          <div className="hidden sm:flex items-center gap-4 text-xs lg:text-sm font-mono text-muted-foreground flex-shrink-0">
            {format(new Date(), "MMM d, yyyy HH:mm:ss")}
          </div>

          {/* Mobile language toggle (header) */}
          <button
            className="lg:hidden flex items-center gap-1.5 px-2.5 py-1.5 rounded-md bg-muted/60 hover:bg-muted text-xs font-medium transition-colors flex-shrink-0"
            onClick={() => setLang(lang === "en" ? "ar" : "en")}
          >
            <Languages className="w-3.5 h-3.5" />
            <span>{lang === "en" ? "عربي" : "EN"}</span>
          </button>
        </header>

        <div className="flex-1 overflow-auto p-4 lg:p-8 relative">
          <div className="max-w-7xl mx-auto space-y-5 lg:space-y-8">{children}</div>
        </div>
      </main>
    </div>
  );
}
