import { Router } from "express";
import type { IRouter } from "express";

const router: IRouter = Router();

router.get("/disease/risk", async (req, res): Promise<void> => {
  const overallRisk = Math.round((42 + (Math.random() - 0.5) * 8) * 10) / 10;
  const riskLevel: "low" | "moderate" | "high" | "critical" =
    overallRisk >= 75 ? "critical" : overallRisk >= 50 ? "high" : overallRisk >= 30 ? "moderate" : "low";

  const zones = [
    { zoneId: "zone-a", zoneName: "Zone A — Tomatoes", humidity: 64, leafWetness: 18, shadePercent: 22, riskScore: 28 },
    { zoneId: "zone-b", zoneName: "Zone B — Peppers", humidity: 78, leafWetness: 34, shadePercent: 48, riskScore: 67 },
    { zoneId: "zone-c", zoneName: "Zone C — Lettuce", humidity: 71, leafWetness: 26, shadePercent: 35, riskScore: 44 },
    { zoneId: "zone-d", zoneName: "Zone D — Basil", humidity: 58, leafWetness: 12, shadePercent: 18, riskScore: 19 },
    { zoneId: "zone-e", zoneName: "Zone E — Eggplant", humidity: 66, leafWetness: 22, shadePercent: 30, riskScore: 35 },
    { zoneId: "zone-f", zoneName: "Zone F — Zucchini", humidity: 73, leafWetness: 29, shadePercent: 40, riskScore: 51 },
  ];

  res.json({
    overallRisk,
    riskLevel,
    primaryThreat: "Powdery Mildew (Erysiphe cichoracearum)",
    probability48h: Math.round((0.34 + (Math.random() - 0.5) * 0.1) * 100) / 100,
    zones: zones.map((z) => ({
      ...z,
      humidity: Math.round((z.humidity + (Math.random() - 0.5) * 4) * 10) / 10,
      riskScore: Math.round((z.riskScore + (Math.random() - 0.5) * 5) * 10) / 10,
      pathogenDetected: z.riskScore > 60,
    })),
    recommendations: [
      "Activate ventilation fans in Zone B immediately — humidity critical",
      "Reduce shade in Zone B from 48% to below 35% within 2 hours",
      "Apply preventive fungicide spray to Zone F within 24 hours",
      "Increase air circulation across all zones — reduce leaf wetness duration",
      "Monitor Zone C closely — humidity trending up in forecast",
    ],
    modelVersion: "TomCast-v4.2+ResNet50",
  });
});

export default router;
