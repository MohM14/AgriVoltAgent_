import { Router } from "express";
import type { IRouter } from "express";

const router: IRouter = Router();

function getHourlyPrice(hour: number) {
  const peakHours = [9, 10, 11, 14, 15, 16];
  const basePrice = 0.18;
  if (peakHours.includes(hour)) return basePrice + 0.18 + Math.random() * 0.08;
  if (hour < 6 || hour > 21) return basePrice - 0.06 + Math.random() * 0.04;
  return basePrice + 0.06 + Math.random() * 0.06;
}

function getCropIndex(hour: number) {
  return Math.round((120 + Math.sin(hour / 24 * Math.PI * 2) * 12 + (Math.random() - 0.5) * 6) * 10) / 10;
}

router.get("/market/prices", async (req, res): Promise<void> => {
  const hour = new Date().getHours();
  const energySpotPrice = Math.round(getHourlyPrice(hour) * 1000) / 1000;
  const prevPrice = getHourlyPrice(hour - 1);
  const cropIndex = getCropIndex(hour);
  const prevCrop = getCropIndex(hour - 1);

  const energyTrend: "rising" | "falling" | "stable" =
    energySpotPrice > prevPrice + 0.01 ? "rising" : energySpotPrice < prevPrice - 0.01 ? "falling" : "stable";
  const cropTrend: "rising" | "falling" | "stable" =
    cropIndex > prevCrop + 1 ? "rising" : cropIndex < prevCrop - 1 ? "falling" : "stable";

  const optimalMode: "maximize_energy" | "maximize_crop" | "balanced" =
    energySpotPrice > 0.35 ? "maximize_energy" : energySpotPrice < 0.22 ? "maximize_crop" : "balanced";

  const recommendations = {
    maximize_energy: "Energy spot price is at peak — maximize solar output now. Defer shade operations until 17:00.",
    maximize_crop: "Energy prices are low. Prioritize crop growth and water optimization over solar output.",
    balanced: "Market conditions are neutral. Maintain current negotiated balance across energy and crop objectives.",
  };

  res.json({
    energySpotPrice,
    energyUnit: "$/kWh",
    cropIndex,
    cropUnit: "index",
    energyTrend,
    cropTrend,
    optimalMode,
    recommendation: recommendations[optimalMode],
    timestamp: new Date().toISOString(),
  });
});

router.get("/market/forecast", async (req, res): Promise<void> => {
  const now = new Date();
  const forecast = [];
  for (let i = 0; i < 24; i++) {
    const ts = new Date(now.getTime() + i * 3600000);
    const hour = ts.getHours();
    const energyPrice = Math.round(getHourlyPrice(hour) * 1000) / 1000;
    const cropIndex = getCropIndex(hour);
    const recommendedMode =
      energyPrice > 0.35 ? "maximize_energy" : energyPrice < 0.22 ? "maximize_crop" : "balanced";
    forecast.push({
      hour: i,
      timestamp: ts.toISOString(),
      energyPrice,
      cropIndex,
      recommendedMode,
    });
  }
  res.json(forecast);
});

export default router;
