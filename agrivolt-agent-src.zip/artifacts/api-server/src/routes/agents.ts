import { Router } from "express";
import type { IRouter } from "express";

const router: IRouter = Router();

const AGENTS = [
  {
    id: "weather",
    name: "Weather Agent",
    role: "Forecast integration",
    status: "idle" as const,
    currentAction: "6-hour forecast: 43°C peak at 13:00 — microclimate model updated",
    utilityScore: 0.95,
    lastUpdated: new Date().toISOString(),
    metrics: {
      temperatureCelsius: 42,
      humidity: 28,
      windSpeedMs: 3.4,
      forecastHours: 6,
      forecastConfidence: 0.91,
    },
  },
  {
    id: "energy",
    name: "Energy Agent",
    role: "Energy maximization",
    status: "active" as const,
    currentAction: "Monitoring irradiance 847 W/m² — optimal tilt 22° for $0.42/kWh peak",
    utilityScore: 0.88,
    lastUpdated: new Date().toISOString(),
    metrics: {
      irradiance: 847,
      panelEfficiency: 21.3,
      currentOutputKw: 142.6,
      targetOutputKw: 160,
      cloudCoverPercent: 8,
    },
  },
  {
    id: "crop",
    name: "Crop Agent",
    role: "Growth optimization",
    status: "negotiating" as const,
    currentAction: "Requesting 40% shade — tomatoes at heat stress threshold 38°C",
    utilityScore: 0.71,
    lastUpdated: new Date().toISOString(),
    metrics: {
      soilMoisture: 68,
      leafAreaIndex: 3.4,
      growthRate: 0.82,
      heatStressIndex: 0.76,
      yieldForecastKgM2: 2.84,
    },
  },
  {
    id: "disease",
    name: "Disease Agent",
    role: "Pathogen prevention",
    status: "active" as const,
    currentAction: "WARNING: Zone B humidity 78% — powdery mildew risk in 48h (TomCast+ResNet-50)",
    utilityScore: 0.93,
    lastUpdated: new Date().toISOString(),
    metrics: {
      overallRiskScore: 42,
      zonesMonitored: 6,
      activeAlerts: 2,
      pathogensTracked: 4,
      hoursToOutbreak: 48,
    },
  },
  {
    id: "water",
    name: "Water Agent",
    role: "Irrigation efficiency",
    status: "active" as const,
    currentAction: "Penman-Monteith model — shade reducing evaporation 35%, adjusting Zone C drip",
    utilityScore: 0.81,
    lastUpdated: new Date().toISOString(),
    metrics: {
      currentFlowRateLph: 340,
      soilMoistureAvg: 67,
      evapotranspirationMm: 3.2,
      waterSavedLiters: 1420,
      savingsPercent: 35,
    },
  },
  {
    id: "market",
    name: "Market Agent",
    role: "Revenue optimization",
    status: "active" as const,
    currentAction: "Energy peak $0.42/kWh until 16:30 — recommending full solar over crop shade",
    utilityScore: 0.84,
    lastUpdated: new Date().toISOString(),
    metrics: {
      energySpotPrice: 0.42,
      cropIndex: 127.4,
      projectedRevenueSAR: 14400,
      marketConfidence: 0.78,
      optimalTiltDegrees: 22,
    },
  },
  {
    id: "supervisor",
    name: "Supervisor Agent",
    role: "Negotiation & coordination",
    status: "negotiating" as const,
    currentAction: "Nash bargaining round 3/6 — computing Pareto frontier via NSGA-III iter 7/20",
    utilityScore: 0.91,
    lastUpdated: new Date().toISOString(),
    metrics: {
      cyclesCompleted: 847,
      avgResolutionMs: 2340,
      consensusRate: 0.94,
      paretoScore: 0.82,
      nashEquilibriumDist: 0.034,
    },
  },
];

function freshAgents() {
  const now = new Date();
  return AGENTS.map((a) => ({
    ...a,
    lastUpdated: now.toISOString(),
    utilityScore: Math.min(1, Math.max(0, a.utilityScore + (Math.random() - 0.5) * 0.06)),
  }));
}

router.get("/agents", async (req, res): Promise<void> => {
  res.json(freshAgents());
});

router.get("/agents/:agentId", async (req, res): Promise<void> => {
  const agent = AGENTS.find((a) => a.id === req.params.agentId);
  if (!agent) {
    res.status(404).json({ error: "Agent not found" });
    return;
  }
  res.json({ ...agent, lastUpdated: new Date().toISOString() });
});

export default router;
