import { Router, type IRouter } from "express";
import healthRouter from "./health";
import agentsRouter from "./agents";
import farmRouter from "./farm";
import negotiationRouter from "./negotiation";
import diseaseRouter from "./disease";
import marketRouter from "./market";

const router: IRouter = Router();

router.use(healthRouter);
router.use(agentsRouter);
router.use(farmRouter);
router.use(negotiationRouter);
router.use(diseaseRouter);
router.use(marketRouter);

export default router;
