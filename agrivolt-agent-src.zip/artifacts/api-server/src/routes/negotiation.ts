import { Router } from "express";
import type { IRouter } from "express";

const router: IRouter = Router();

function generateSession(id: string, isComplete: boolean, minutesAgo: number) {
  const startedAt = new Date(Date.now() - minutesAgo * 60000);
  const completedAt = isComplete ? new Date(startedAt.getTime() + 45000) : null;

  const resolutions = [
    {
      action: "25% panel tilt, activate mist cooling, defer shade 2 hours",
      panelTiltDegrees: 25,
      irrigationRate: 0.65,
      explanation:
        "Nash equilibrium at 25° tilt — solar output 89% efficient while mitigating crop heat stress. Disease agent veto on full shade upheld (humidity 78% in Zone B). Mist cooling compensates within 45 min. Pareto optimal solution with social welfare 0.82.",
      winningAgents: ["energy", "supervisor", "market"],
      compensationCredits: {
        crop: 0.34,
        disease: 0.18,
        water: 0.09,
      },
    },
    {
      action: "Full shade 90 min, increase drip irrigation 40%, ventilate Zone B",
      panelTiltDegrees: 72,
      irrigationRate: 1.4,
      explanation:
        "Crop heat stress index crossed 0.85 threshold. Market agent conceded peak-price window to prevent yield loss of ~SAR 1,560. Disease agent cleared shade request given humidity drop post-ventilation.",
      winningAgents: ["crop", "water", "disease"],
      compensationCredits: {
        energy: 0.52,
        market: 0.28,
      },
    },
    {
      action: "Balanced 40° tilt, standard irrigation, ventilation on Zone B",
      panelTiltDegrees: 40,
      irrigationRate: 0.9,
      explanation:
        "Pareto optimal — all agents within 15% of individual maxima. Disease agent triggered Zone B ventilation as preventive measure. Penman-Monteith confirms 35% water savings maintained. Social welfare score 0.84.",
      winningAgents: ["supervisor"],
      compensationCredits: {
        energy: 0.12,
        crop: 0.21,
        disease: 0.31,
        water: 0.05,
      },
    },
  ];

  // Matches the live scenario from the pitch (Slide 9)
  const bids = [
    {
      agentId: "energy",
      agentName: "Energy Agent",
      bid: "Full sun — energy prices peak at $0.42/kWh",
      utilityGain: 0.89,
      constraints: ["Panel efficiency > 18%", "No tilt beyond 30°"],
      priority: 0.88,
    },
    {
      agentId: "crop",
      agentName: "Crop Agent",
      bid: "Need 40% shade — heat stress above 38°C",
      utilityGain: 0.76,
      constraints: ["Shade ≥ 35%", "Soil moisture ≥ 60%"],
      priority: 0.71,
    },
    {
      agentId: "disease",
      agentName: "Disease Agent",
      bid: "WARNING: shade + humidity >75% = powdery mildew in 48h",
      utilityGain: 0.93,
      constraints: ["Humidity < 75% OR ventilation active", "Shade < 50%"],
      priority: 0.93,
    },
    {
      agentId: "water",
      agentName: "Water Agent",
      bid: "Reduce irrigation 35% — shade lowering evaporation (Penman-Monteith)",
      utilityGain: 0.68,
      constraints: ["Soil moisture ≥ 55%", "Flow rate 250–450 L/h"],
      priority: 0.81,
    },
    {
      agentId: "market",
      agentName: "Market Agent",
      bid: "Maximize energy — spot price $0.42/kWh until 16:30",
      utilityGain: 0.84,
      constraints: ["Revenue delta > SAR 300 before conceding shade"],
      priority: 0.84,
    },
    {
      agentId: "supervisor",
      agentName: "Supervisor Agent",
      bid: "Solution: 25° tilt, mist cooling, defer shade 2h",
      utilityGain: 0.91,
      constraints: ["All agent constraints satisfied", "Pareto score > 0.75"],
      priority: 0.91,
    },
  ];

  const res = resolutions[parseInt(id, 36) % resolutions.length];

  return {
    id,
    startedAt: startedAt.toISOString(),
    completedAt: completedAt?.toISOString() ?? null,
    status: isComplete ? ("completed" as const) : ("in_progress" as const),
    bids,
    resolution: isComplete ? res : null,
    paretoScore: isComplete ? Math.round((0.78 + Math.random() * 0.14) * 100) / 100 : 0,
    socialWelfareScore: isComplete ? Math.round((0.74 + Math.random() * 0.16) * 100) / 100 : 0,
  };
}

router.get("/negotiation/sessions", async (req, res): Promise<void> => {
  const limit = Number(req.query.limit) || 10;
  const sessions = [];
  for (let i = 0; i < Math.min(limit, 20); i++) {
    const id = (847 - i).toString(36);
    sessions.push(generateSession(id, true, (i + 1) * 15));
  }
  res.json(sessions);
});

router.get("/negotiation/current", async (req, res): Promise<void> => {
  const session = generateSession("847", false, 2);
  res.json(session);
});

export default router;
