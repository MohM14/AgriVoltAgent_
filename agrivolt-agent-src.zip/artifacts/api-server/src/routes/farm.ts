import { Router } from "express";
import type { IRouter } from "express";

const router: IRouter = Router();

let cycleCount = 847;
let nextCycleIn = 540; // seconds

setInterval(() => {
  nextCycleIn = Math.max(0, nextCycleIn - 1);
  if (nextCycleIn === 0) {
    cycleCount++;
    nextCycleIn = 900; // 15 min
  }
}, 1000);

function getFarmMetrics() {
  const now = new Date();
  const hour = now.getHours();
  // Saudi Arabia: peak solar from 9–15h, high base irradiance
  const solarFactor = Math.max(0, Math.sin(((hour - 6) / 12) * Math.PI));

  return {
    energyOutput: Math.round((142.6 + (Math.random() - 0.5) * 8) * solarFactor * 10) / 10,
    cropYield: Math.round((2840 + (Math.random() - 0.5) * 40) * 10) / 10,
    waterUsage: Math.round((340 + (Math.random() - 0.5) * 20) * 10) / 10,
    // 35% water savings target per Penman-Monteith model (pitch Slide 12)
    waterSavings: Math.round((1420 + (Math.random() - 0.5) * 40) * 10) / 10,
    diseaseRiskScore: Math.round((42 + (Math.random() - 0.5) * 4) * 10) / 10,
    revenueToday: Math.round((14400 + (Math.random() - 0.5) * 400) * 10) / 10, // SAR
    // 22% land use efficiency via food+energy co-location (pitch Slide 12)
    landUseEfficiency: Math.round((1.22 + (Math.random() - 0.5) * 0.02) * 100) / 100,
    panelTiltDegrees: Math.round((25 + (Math.random() - 0.5) * 3) * 10) / 10,
    irrigationActive: Math.random() > 0.3,
    alertCount: Math.random() > 0.7 ? 2 : 1,
    cycleCount,
    nextCycleIn,
  };
}

function getSensors() {
  // Saudi Arabia crops: Tomatoes, Dates, Peppers, Lettuce, Eggplant, Herbs
  const zones = [
    "Zone A — طماطم",
    "Zone B — فلفل",
    "Zone C — خس",
    "Zone D — تمور",
    "Zone E — باذنجان",
    "Zone F — أعشاب",
  ];
  const types = [
    // Higher base temps for Saudi desert conditions
    { type: "temperature", unit: "°C", baseValue: 42, range: 5 },
    { type: "humidity", unit: "%", baseValue: 32, range: 12 },
    { type: "soil_moisture", unit: "%", baseValue: 67, range: 8 },
    { type: "light_intensity", unit: "W/m²", baseValue: 820, range: 100 },
  ];

  const readings = [];
  for (const zone of zones) {
    for (const t of types) {
      const value = Math.round((t.baseValue + (Math.random() - 0.5) * t.range) * 10) / 10;
      let status: "normal" | "warning" | "critical" = "normal";
      if (t.type === "humidity" && value > 75) status = value > 82 ? "critical" : "warning";
      if (t.type === "temperature" && value > 44) status = value > 47 ? "critical" : "warning";
      if (t.type === "soil_moisture" && value < 50) status = value < 40 ? "critical" : "warning";

      readings.push({
        id: `${zone.split(" ")[1].toLowerCase()}-${t.type}`,
        zone,
        type: t.type.replace(/_/g, " "),
        value,
        unit: t.unit,
        timestamp: new Date().toISOString(),
        status,
      });
    }
  }
  return readings;
}

function getHistory(hours: number) {
  const now = Date.now();
  const points = [];
  for (let i = hours; i >= 0; i -= 1) {
    const ts = new Date(now - i * 3600000);
    const hour = ts.getHours();
    const solar = Math.max(0, Math.sin(((hour - 6) / 12) * Math.PI));
    points.push({
      timestamp: ts.toISOString(),
      energyOutput: Math.round((solar * 145 + (Math.random() - 0.5) * 10) * 10) / 10,
      cropHealth: Math.round((78 + (Math.random() - 0.5) * 6) * 10) / 10,
      waterUsage: Math.round((320 + (Math.random() - 0.5) * 40) * 10) / 10,
      diseaseRisk: Math.round((38 + (Math.random() - 0.5) * 15) * 10) / 10,
      revenue: Math.round((solar * 400 + (Math.random() - 0.5) * 50) * 10) / 10,
    });
  }
  return points;
}

router.get("/farm/metrics", async (req, res): Promise<void> => {
  res.json(getFarmMetrics());
});

router.get("/farm/sensors", async (req, res): Promise<void> => {
  res.json(getSensors());
});

router.get("/farm/history", async (req, res): Promise<void> => {
  const hours = Number(req.query.hours) || 24;
  res.json(getHistory(Math.min(168, Math.max(1, hours))));
});

export default router;
