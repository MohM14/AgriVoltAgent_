# AgriVoltAgent — منظومة وكلاء الزراعة الذكية

## Overview

A real-time multi-agent operations dashboard for agrivoltaic farms in Saudi Arabia — where 7 AI agents autonomously negotiate energy vs. food trade-offs every 15 minutes. Built as an MVP for AgriVoltAgent Agenticthon 2026, targeting Saudi Vision 2030 (50% renewables + food security).

**Product name**: AgriVoltAgent  
**Target market**: Saudi Arabia (117.9B SAR agricultural output, 45°C heat stress, 30% water waste)  
**Key outcomes**: 35% water savings, 22% land efficiency, 20% revenue increase, 48h disease early warning

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **Frontend**: React + Vite (artifacts/ais-dashboard) — dark theme with solar amber + forest green
- **API framework**: Express 5 (artifacts/api-server)
- **API contracts**: OpenAPI 3.1 → codegen via Orval
- **Charts**: Recharts
- **Routing**: Wouter
- **Animation**: Framer Motion
- **Database**: PostgreSQL + Drizzle ORM (provisioned, not yet used for persisted data)
- **Validation**: Zod (zod/v4), drizzle-zod

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

## Application Pages

- `/` — Dashboard: live farm metrics, agent status, negotiation resolution
- `/agents` — All 8 AI agents: Solar, Crop, Disease, Water, Weather, Market, Coordinator, Negotiator
- `/negotiation` — Live negotiation sessions: agent bids, Nash bargaining, Pareto scores
- `/disease` — Disease risk monitoring: 48h outbreak prediction, zone breakdown (TomCast + ResNet-50)
- `/market` — Energy & crop market pricing, 24h forecast chart
- `/sensors` — IoT sensor readings across 6 farm zones
- `/history` — Historical performance charts: energy, crop health, water, disease risk, revenue

## API Routes

All data is simulated (realistically) — refreshes on 15-second cycles matching the negotiation protocol:

- `GET /api/agents` — all 8 agent statuses with utility scores
- `GET /api/agents/:id` — single agent detail
- `GET /api/negotiation/current` — live negotiation session with bids
- `GET /api/negotiation/sessions` — recent completed sessions
- `GET /api/farm/metrics` — farm control state
- `GET /api/farm/sensors` — IoT sensor grid
- `GET /api/farm/history?hours=24` — historical data
- `GET /api/disease/risk` — disease risk assessment with zone breakdown
- `GET /api/market/prices` — current energy/crop prices with trend
- `GET /api/market/forecast` — 24-hour price forecast

## Architecture Notes

- Frontend polls key data at 15s intervals (matching negotiation cycle)
- Backend generates realistic simulated data with proper time-of-day curves for solar output and energy pricing
- Disease model simulates TomCast epidemiological + CNN leaf classifier outputs
- Market agent simulates peak/off-peak energy pricing with NSGA-III negotiation resolution
